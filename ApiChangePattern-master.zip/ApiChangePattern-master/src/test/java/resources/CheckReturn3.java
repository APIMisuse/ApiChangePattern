package resources;

public class CheckReturn3 {
		
	public int a(){
		return 1;
	}
	
	public boolean b(){
		return false;
	}	
	
	public boolean c(){
		CheckReturn3 test = new CheckReturn3();
		test.b();
		test.a();
		return false;

	}
}

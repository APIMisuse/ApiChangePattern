package resources;

public class CheckReturn4 {
	
	public int a(){
		return 1;
	}
	
	public boolean b(){
		return false;
	}
	
	public boolean c(){
		CheckReturn4 test = new CheckReturn4();
		boolean result = test.b();
		if(result== true)
			return false;
		int i = test.a();
		if(i-1>0)
			return true;
		return false;
		
		
	}
}

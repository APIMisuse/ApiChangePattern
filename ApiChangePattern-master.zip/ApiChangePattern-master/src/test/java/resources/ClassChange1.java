package resources;

import java.util.Arrays;

import org.apache.poi.ss.formula.functions.T;

public class ClassChange1 {
	
	public void add(T value,T[] array,T[] temp) {
		temp = Arrays.copyOf(array, 1);;
	}

}

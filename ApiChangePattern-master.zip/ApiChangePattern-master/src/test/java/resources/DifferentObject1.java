package resources;

public class DifferentObject1 {
	public void test(String c)
	{
		StringBuilder a = null;
		StringBuilder b = null;
		a.append("test");	
		a.append("test");
		a.append("test");
		a.toString();
		a.toString();	
		c.toString();
	}
}

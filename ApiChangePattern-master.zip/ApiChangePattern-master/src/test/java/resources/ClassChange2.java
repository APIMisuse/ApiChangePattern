package resources;

import org.apache.poi.ss.formula.functions.T;

public class ClassChange2 {
	
	public void add(T value,T[] array,T[] temp) {

        System.arraycopy(array,0,temp,0,1);
}

}

package resources;

public class UseA2 {
	public String getStatic(){
		return A.s.substring(0);
	}
}

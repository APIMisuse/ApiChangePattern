package resources;

public class CheckReturn6 {
	
	public boolean b(){
		return false;
	}
	
	public void setJDBC1(){
		if(System.setProperty("jdbc.drivers","oracle.jdbc.driver.OracleDriver")!=null)
		{
			System.setProperty("jdbc.drivers","oracle.jdbc.driver.OracleDriver");
			System.setProperty("jdbc.drivers","oracle.jdbc.driver.OracleDriver");
		}
	}

}

package resources;

public class Append2 {
	public void test(String str1,String str2)
	{
		StringBuilder a = null;
		a.append(str1).append(str2);
	}
}

package resources;

import java.net.URISyntaxException;
import java.net.URL;
import java.security.NoSuchAlgorithmException;
import java.security.Policy;
import java.util.*;

public class elasicsearch2 {
	 static Policy readPolicy(URL policyFile, Set<URL> codebases) {
         List<String> propertiesSet = new ArrayList<>();
		try {
		    // set codebase properties
		    for (URL url : codebases) {
		        String fileName = "aaaa";
		        if (fileName.endsWith(".jar") == false) {
		            continue; // tests :(
		        }                    
		        // We attempt to use a versionless identifier for each codebase. This assumes a specific version
		        // format in the jar filename. While we cannot ensure all jars in all plugins use this format, nonconformity
		        // only means policy grants would need to include the entire jar filename as they always have before.
		        String property = "codebase." + fileName;
		        String aliasProperty = "codebase." + fileName.replaceFirst("-\\d+\\.\\d+.*\\.jar", "");
		        if (aliasProperty.equals(property) == false) {
		            propertiesSet.add(aliasProperty);
		            String previous = System.setProperty(aliasProperty, url.toString());
		            if (previous != null) {
		                throw new IllegalStateException("codebase property already set: " + aliasProperty + " -> " + previous +
		                                                ", cannot set to " + url.toString());
		            }
		        }
		        propertiesSet.add(property);
		        String previous = System.setProperty(property, url.toString());
		        if (previous != null) {
		            throw new IllegalStateException("codebase property already set: " + property + " -> " + previous +
		                                            ", cannot set to " + url.toString());
		        }
		    }
		    return null;
		 } finally {
		     // clear codebase properties
		     for (String property : propertiesSet) {
		         System.clearProperty(property);
		     }
		 }
}
}

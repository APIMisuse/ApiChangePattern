package resources;

import java.net.URISyntaxException;
import java.net.URL;
import java.security.NoSuchAlgorithmException;
import java.security.Policy;
import java.util.*;

import cn.edu.fudan.se.apiChangeExtractor.util.PathUtils;

public class elasicsearch1 {
		  static Policy readPolicy(URL policyFile, Set<URL> codebases) {
		             List<String> propertiesSet = new ArrayList<>();
		            try {
		                // set codebase properties
		                for (URL url : codebases) {
		                    String shortName = "aaaaa";
		                    if (shortName.endsWith(".jar") == false) {
		                        continue; // tests :(
		                    }
		                    String property = "codebase." + shortName;
		                    if (shortName.startsWith("elasticsearch-rest-client")) {
		                        // The rest client is currently the only example where we have an elasticsearch built artifact
		                        // which needs special permissions in policy files when used. This temporary solution is to
		                        // pass in an extra system property that omits the -version.jar suffix the other properties have.
		                        // That allows the snapshots to reference snapshot builds of the client, and release builds to
		                        // referenced release builds of the client, all with the same grant statements.
		                        final String esVersion = "-SNAPSHOT";
		                        final int index = property.indexOf("-" + esVersion + ".jar");
		                        assert index >= 0;
		                        String restClientAlias = property.substring(0, index);
		                        propertiesSet.add(restClientAlias);
		                        System.setProperty(restClientAlias, url.toString());
		                    }
		                    propertiesSet.add(property);
		                    String previous = System.setProperty(property, url.toString());
		                    if (previous != null) {
		                        throw new IllegalStateException("codebase property already set: " + shortName + "->" + previous);		                 
		                    }
		                }
		                return null;
		             } finally {
		                 // clear codebase properties
		                 for (String property : propertiesSet) {
		                     System.clearProperty(property);
		                 }
		             }		         
		}
}

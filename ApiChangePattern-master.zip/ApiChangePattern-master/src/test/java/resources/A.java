package resources;

public class A {
	static String s = "";
}

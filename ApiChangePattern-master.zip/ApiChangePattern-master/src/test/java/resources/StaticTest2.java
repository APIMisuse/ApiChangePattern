package resources;

public class StaticTest2 {

	public void test()
	{
		System.out.println("Hello,World");
	}
}

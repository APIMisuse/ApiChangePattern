package resources;

public class CheckReturn8 {

	public boolean b(){
		return false;
	}
	
	public void setJDBC2(){
		String a = System.setProperty("jdbc.drivers","oracle.jdbc.driver.OracleDriver");
	}
}

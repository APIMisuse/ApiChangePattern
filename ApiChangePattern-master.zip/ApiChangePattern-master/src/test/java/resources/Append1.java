package resources;

public class Append1 {
	public void test(String str1,String str2)
	{
		StringBuilder a = null;
		a.append(str1);
		a.append(str2);
	}
}

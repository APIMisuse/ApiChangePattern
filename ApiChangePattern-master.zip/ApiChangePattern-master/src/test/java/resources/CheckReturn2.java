package resources;

public class CheckReturn2 {
	
	public boolean b(){
		return false;
	}
	
	public boolean a(){
		CheckReturn2 test = new CheckReturn2();
		if(test.b() && true || true)
			return true;
		return false;
	}
}

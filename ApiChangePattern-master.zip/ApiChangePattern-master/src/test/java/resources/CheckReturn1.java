package resources;

public class CheckReturn1 {
	
	public boolean b(){
		return false;
	}
	
	public boolean a(){
		CheckReturn1 test = new CheckReturn1();
		test.b();
		return false;
	}	
}

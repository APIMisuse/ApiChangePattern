package resources;

public class DifferentObject2 {
	public void test(String c)
	{
		StringBuilder a = null;
		StringBuilder b = null;
		b.append("test");		
		b.append("tes");
		a.append("tes");
		b.toString();
		b.append("tes");
		b.toString();
	}
}

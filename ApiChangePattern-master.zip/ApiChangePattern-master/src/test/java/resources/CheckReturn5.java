package resources;

public class CheckReturn5 {
	
	public boolean b(){
		return false;
	}
	
	public void setJDBC1(){
		System.setProperty("jdbc.drivers","oracle.jdbc.driver.OracleDriver");
	}

}

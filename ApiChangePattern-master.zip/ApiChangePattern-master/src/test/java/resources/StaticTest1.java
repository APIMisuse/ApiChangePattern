package resources;

import static java.lang.System.out;

public class StaticTest1 {
    
	public void test()
	{
		out.println("Hello,World");
	}
}

package resources;

public class UseA1 {
	public String getStatic(){
		return A.s.intern();
	}
}

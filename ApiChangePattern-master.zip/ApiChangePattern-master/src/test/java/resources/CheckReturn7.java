package resources;

public class CheckReturn7 {

	public boolean b(){
		return false;
	}

	public void setJDBC2(){
		System.setProperty("jdbc.drivers","oracle.jdbc.driver.OracleDriver");
	}
}

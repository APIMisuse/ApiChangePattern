package cn.edu.fudan.se.test;

import org.junit.Test;

import cn.edu.fudan.se.apiChangeExtractor.RepeatCounter;

public class CountRepeat {
	@Test
	public void test(){
		RepeatCounter rc = new RepeatCounter();
		rc.countAndInsert();
	}
}

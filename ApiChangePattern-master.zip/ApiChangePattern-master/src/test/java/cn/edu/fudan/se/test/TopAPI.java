package cn.edu.fudan.se.test;

import java.io.IOException;

import org.junit.Test;

import cn.edu.fudan.se.apiChangeExtractor.RepeatCounter;

public class TopAPI {
	@Test
	public void test() throws IOException{
		
		RepeatCounter rc = new RepeatCounter();
		rc.createTopApi();
		rc.updateTopApiBugR();
		rc.updateTopApiBugTotal();
	}
}


package cn.edu.fudan.se.apiChangeExtractor.mybatis.bean;

public class ApiRankList {
	private String className;
	private String methodName;
	private int bugTotal;
	private int bugR;
	private double rate;
	private double bugRank;
	
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getMethodName() {
		return methodName;
	}
	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}
	public int getBugTotal() {
		return bugTotal;
	}
	public void setBugTotal(int bugTotal) {
		this.bugTotal = bugTotal;
	}
	public int getBugR() {
		return bugR;
	}
	public void setBugR(int bugR) {
		this.bugR = bugR;
	}
	public double getRate() {
		return rate;
	}
	public void setRate(double rate) {
		this.rate = rate;
	}
	public double getBugRank() {
		return bugRank;
	}
	public void setBugRank(double bugRank) {
		this.bugRank = bugRank;
	} 
	
	
}

package cn.edu.fudan.se.apiChangeExtractor.mybatis.bean;

public class InnerChangeExample {
	
	private int innerExampleId;
	private int repositoryId;
	private int exampleId;
	private int innerRepeatNum;
	public int getInnerExampleId() {
		return innerExampleId;
	}
	public void setInnerExampleId(int innerExampleId) {
		this.innerExampleId = innerExampleId;
	}
	public int getRepositoryId() {
		return repositoryId;
	}
	public void setRepositoryId(int repositoryId) {
		this.repositoryId = repositoryId;
	}
	public int getExampleId() {
		return exampleId;
	}
	public void setExampleId(int exampleId) {
		this.exampleId = exampleId;
	}
	public int getInnerRepeatNum() {
		return innerRepeatNum;
	}
	public void setInnerRepeatNum(int innerRepeatNum) {
		this.innerRepeatNum = innerRepeatNum;
	}
}

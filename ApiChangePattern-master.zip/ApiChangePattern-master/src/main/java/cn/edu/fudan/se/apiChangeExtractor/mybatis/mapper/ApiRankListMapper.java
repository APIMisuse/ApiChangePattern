package cn.edu.fudan.se.apiChangeExtractor.mybatis.mapper;

import java.util.List;

import cn.edu.fudan.se.apiChangeExtractor.mybatis.bean.ApiRankList;
import cn.edu.fudan.se.apiChangeExtractor.mybatis.bean.RankTime;

public interface ApiRankListMapper {

	public List<ApiRankList> getTotal(RankTime rt);

}

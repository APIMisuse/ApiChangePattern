package cn.edu.fudan.se.apiChangeExtractor;

import java.util.List;
import java.util.Stack;

import org.eclipse.jdt.core.dom.MethodInvocation;

import com.github.gumtreediff.actions.model.Action;
import com.github.gumtreediff.actions.model.Delete;
import com.github.gumtreediff.actions.model.Insert;
import com.github.gumtreediff.actions.model.Move;
import com.github.gumtreediff.actions.model.Update;
import com.github.gumtreediff.tree.ITree;
import com.github.gumtreediff.tree.Tree;
import com.github.gumtreediff.tree.TreeContext;

import cn.edu.fudan.se.apiChangeExtractor.bean.JdtMethodCall;
import cn.edu.fudan.se.apiChangeExtractor.bean.Transition;
import cn.edu.fudan.se.apiChangeExtractor.gumtreeParser.GumTreeDiffParser;

public class PatternMatcher 
{
    
/*	
	return值列表
	1   参数个数
    2 A.a→a'=A.a
    3 A.a→B.a
    4 A.a→A.b
    5 A.a(c)→A.a(d) 
*/
	public enum ChangeType
	{
		NOT_FOUND,
		RETURN_VALUE_ASSIGNMENT,
		CHANGE_METHOD,
		CHANGE_PAREMETER,
		CHANGE_CLASSOBJECT,
		CHANGE_CLASSOBJECT_REST,
		DIFFERENT_CLASS
	}
	
    public ChangeType matchOneAction(Action a, TreeContext dstTC , GumTreeDiffParser diff, Transition rl)
    {
//    	System.out.println("********************match*******************");
    	ITree node = a.getNode();
		ITree parent = node.getParent();
		int position  = parent.getChildPosition(node);

		if(a instanceof Update && "TypeDeclaration".equals(dstTC.getTypeLabel(parent)))
		{
			ITree newNode = null; 
			ITree oldNode = null;
			oldNode = a.getNode();
			newNode = diff.getMapping().getDst(oldNode);
			rl.renameMap.put(oldNode.getLabel(), newNode.getLabel());					
		}
		
		if(a instanceof Insert)
		{
			Insert insert = (Insert)a;
			ITree insertNode = insert.getNode();
			if(insert.getPosition()>1 && "MethodInvocation".equals(dstTC.getTypeLabel(node)))	
			{			
				ITree newNode = null; 
				ITree oldNode = null;
				oldNode = a.getNode();
				newNode = diff.getMapping().getDst(oldNode);
				if(oldNode!=null && newNode!= null)
				{
					JdtMethodCall oldCall = null;
					JdtMethodCall newCall = null;
					if(((Tree)oldNode.getParent()).getAstNode() instanceof MethodInvocation){	
						MethodInvocation tempMI = (MethodInvocation)((Tree)oldNode.getParent()).getAstNode();
						oldCall = diff.getJdkMethodCall(tempMI);
					}
					if(((Tree)newNode.getParent()).getAstNode() instanceof MethodInvocation){
						MethodInvocation tempMI = (MethodInvocation)((Tree)newNode.getParent()).getAstNode();
						newCall = diff.getJdkMethodCall(tempMI);
					}
					if(oldCall!=null && newCall!=null) 
					{
						//receiver类型名字相同，method也相同
						if(oldCall.getInvoker().equals(newCall.getInvoker()))
							if(oldNode.getParent().getChildren().get(0).getLabel()!=null)
								if(oldNode.getParent().getChildren().get(0).getLabel().equals(newNode.getParent().getChildren().get(0).getLabel()))
									if(oldCall.getMethodName().equals(newCall.getMethodName()))
                                        if(oldNode.getParent().getChildren().size()!=newNode.getParent().getChildren().size() )		
                                        	return ChangeType.CHANGE_METHOD;                               
					}
				}		
			}					
		}
		if(a instanceof Delete)
		{
			Delete delete = (Delete)a;
			ITree deleteNode = delete.getNode();
			if(deleteNode.getParent().getChildPosition(deleteNode)>1 && "MethodInvocation".equals(dstTC.getTypeLabel(node)))
			{	
				ITree newNode = null; 
				ITree oldNode = null;
				oldNode = a.getNode();
				newNode = diff.getMapping().getDst(oldNode);
				if(oldNode!=null && newNode!= null)
				{
					JdtMethodCall oldCall = null;
					JdtMethodCall newCall = null;
					if(((Tree)oldNode.getParent()).getAstNode() instanceof MethodInvocation){	
						MethodInvocation tempMI = (MethodInvocation)((Tree)oldNode.getParent()).getAstNode();
						oldCall = diff.getJdkMethodCall(tempMI);
					}
					if(((Tree)newNode.getParent()).getAstNode() instanceof MethodInvocation){
						MethodInvocation tempMI = (MethodInvocation)((Tree)newNode.getParent()).getAstNode();
						newCall = diff.getJdkMethodCall(tempMI);
					}
					if(oldCall!=null && newCall!=null) 
					{
						//receiver类型名字相同，method也相同
						if(oldCall.getInvoker().equals(newCall.getInvoker()))
							if(oldNode.getParent().getChildren().get(0).getLabel()!=null)
								if(oldNode.getParent().getChildren().get(0).getLabel().equals(newNode.getParent().getChildren().get(0).getLabel()))
									if(oldCall.getMethodName().equals(newCall.getMethodName()))
                                        if(oldNode.getParent().getChildren().size()!=newNode.getParent().getChildren().size() )		
                                        	return ChangeType.CHANGE_METHOD;                               
					}
				}		
			}
		}
		//使用返回值
		if(a instanceof Move
				&& "MethodInvocation".equals(dstTC.getTypeLabel(node))
				//&& "VariableDeclarationFragment".equals(dstTC.getTypeLabel(parent))
				){
			Move move = (Move)a;
			//注意moveNode是旧树上的节点
			ITree moveNode = move.getNode();
			if("MethodInvocation".equals(dstTC.getTypeLabel(moveNode))
					&& "VariableDeclarationFragment".equals(dstTC.getTypeLabel(move.getParent()))
					){							
//				System.out.println(((Tree)node).getAstNode().toString());
				ITree statement = node;

				if(statement!=null){
//					System.out.println(((Tree)statement).getAstNode().toString());		
					//遍历整棵树  看是否被放到一个条件判断中去	
//					System.out.println("Start!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
					ITree parentNode = move.getParent().getParent().getParent();
//					System.out.println(dstTC.getTypeLabel(parentNode)+"    "+parentNode.getLabel());
//					System.out.println(dstTC.getTypeLabel(move.getParent().getParent())+"    "+move.getParent().getParent().getLabel());
//					System.out.println(dstTC.getTypeLabel(move.getParent())+"    "+move.getParent().getLabel());
					ITree variableNode = move.getParent().getChild(0);
					Stack<ITree> nodeStack = new Stack<ITree>();
			        nodeStack.add(parentNode);
			        //加上开始标记，防止从变量申明之前就进行了判断
			        int startFlag = 0;
			        while (!nodeStack.isEmpty()) {
			        	ITree currentNode = nodeStack.pop();
			            List<ITree> childrenNodes = currentNode.getChildren();
			            if (childrenNodes != null && !childrenNodes.isEmpty()) 
			            {
			            	for (int i=childrenNodes.size()-1;i>=0;i--) 
			                {
			                	if(childrenNodes.get(i) == move.getParent().getParent())
			                		startFlag = 1;
			            		if(startFlag!=1)
			            		{
			            			ITree childNode = childrenNodes.get(i);
			            			if("IfStatement".equals(dstTC.getTypeLabel(childNode))
			                	    	||"ForStatement".equals(dstTC.getTypeLabel(childNode)))
			            			{
//			            				System.out.println("Start  CheckLabel!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
//			            				System.out.println(childNode.getStartLineNumber()+"."+dstTC.getTypeLabel(childNode));
			            				if(CheckLabel(childNode, variableNode,dstTC))
			            					return ChangeType.RETURN_VALUE_ASSIGNMENT;		                		
			                		}
			                		nodeStack.push(childNode);
			            		}
			                }
			            }
			        }
					
					return ChangeType.NOT_FOUND;
				}
			}
			if("MethodInvocation".equals(dstTC.getTypeLabel(moveNode)))
			{
              if(CheckReturn(move.getParent(),dstTC))
            	  return ChangeType.RETURN_VALUE_ASSIGNMENT;		
			}
		}
		//
		if(a instanceof Update 
				&& "MethodInvocation".equals(dstTC.getTypeLabel(parent))
				&& position == 0){
			
			ITree newNode = null; 
			ITree oldNode = null;
			oldNode = a.getNode();
			newNode = diff.getMapping().getDst(oldNode);
			if(oldNode!=null && newNode!= null)
			{
				JdtMethodCall oldCall = null;
				JdtMethodCall newCall = null;
				if(((Tree)oldNode.getParent()).getAstNode() instanceof MethodInvocation){	
					MethodInvocation tempMI = (MethodInvocation)((Tree)oldNode.getParent()).getAstNode();
					oldCall = diff.getJdkMethodCall(tempMI);
				}
				if(((Tree)newNode.getParent()).getAstNode() instanceof MethodInvocation){
					MethodInvocation tempMI = (MethodInvocation)((Tree)newNode.getParent()).getAstNode();
					newCall = diff.getJdkMethodCall(tempMI);
				}
				if(oldCall!=null && newCall!=null) 
				{
					if(oldCall.getInvoker().toString().equals(newCall.getInvoker().toString()))
					{
						//同类替换  此处需要区分不同对象的方法是否有变化
						//方法没变并且参数simplename也没有变
						oldNode.getParent().getChildren();
						if(oldCall.getMethodName().equals(newCall.getMethodName())&& CheckParameterSimpleName(oldNode,newNode))
                        	return ChangeType.CHANGE_CLASSOBJECT;
                        //换了方法
                        if(!oldCall.getMethodName().equals(newCall.getMethodName()))
                        	return ChangeType.CHANGE_CLASSOBJECT_REST;
                        //方法没换但参数有变化
                        if(oldCall.getMethodName().equals(newCall.getMethodName())
                        	&&!CheckParameterSimpleName(oldNode,newNode) )
                            return ChangeType.CHANGE_CLASSOBJECT_REST;											
					}
					if(!oldCall.getInvoker().toString().equals(newCall.getInvoker().toString()))
					   return ChangeType.DIFFERENT_CLASS;
				}
			}			
		}
		if(a instanceof Update 
				&& "MethodInvocation".equals(dstTC.getTypeLabel(parent))
				&& position == 1){		
			ITree newNode = null; 
			ITree oldNode = null;
			oldNode = a.getNode();
			newNode = diff.getMapping().getDst(oldNode);
			if(oldNode!=null && newNode!= null)
			{
				JdtMethodCall oldCall = null;
				JdtMethodCall newCall = null;
				if(((Tree)oldNode.getParent()).getAstNode() instanceof MethodInvocation){	
					MethodInvocation tempMI = (MethodInvocation)((Tree)oldNode.getParent()).getAstNode();
					oldCall = diff.getJdkMethodCall(tempMI);
				}
				if(((Tree)newNode.getParent()).getAstNode() instanceof MethodInvocation){
					MethodInvocation tempMI = (MethodInvocation)((Tree)newNode.getParent()).getAstNode();
					newCall = diff.getJdkMethodCall(tempMI);
				}
				if(oldCall!=null && newCall!=null) 
				{
					//receiver类型名字相同
					if(oldCall.getInvoker().equals(newCall.getInvoker()))
						if(oldNode.getParent().getChildren().get(0).getLabel().equals(newNode.getParent().getChildren().get(0).getLabel()))
						{
//							System.out.println(oldNode.getParent().getChildren().get(0).getLabel());
//							System.out.println(newNode.getParent().getChildren().get(0).getLabel());
							return ChangeType.CHANGE_METHOD;
						}
				}
			}					
		}
		if(a instanceof Update 
				&& "MethodInvocation".equals(dstTC.getTypeLabel(parent))
				&& position > 1){
		
			Update update = (Update)a;		
			if(rl.renameMap.get(update.getNode().getLabel())!=null)
			    if(rl.renameMap.get(update.getNode().getLabel()).equals(update.getValue()))
                   return ChangeType.NOT_FOUND;		
			
			ITree newNode = null; 
			ITree oldNode = null;
			oldNode = a.getNode();
			newNode = diff.getMapping().getDst(oldNode);
			if(oldNode!=null && newNode!= null)
			{
				JdtMethodCall oldCall = null;
				JdtMethodCall newCall = null;
				if(((Tree)oldNode.getParent()).getAstNode() instanceof MethodInvocation){	
					MethodInvocation tempMI = (MethodInvocation)((Tree)oldNode.getParent()).getAstNode();
					oldCall = diff.getJdkMethodCall(tempMI);
				}
				if(((Tree)newNode.getParent()).getAstNode() instanceof MethodInvocation){
					MethodInvocation tempMI = (MethodInvocation)((Tree)newNode.getParent()).getAstNode();
					newCall = diff.getJdkMethodCall(tempMI);
				}
				if(oldCall!=null && newCall!=null) 
				{
					//receiver类型名字相同，method也相同
					if(oldCall.getInvoker().equals(newCall.getInvoker()))
						if(oldNode.getParent().getChildren().get(0).getLabel()!=null)
							if(oldNode.getParent().getChildren().get(0).getLabel().equals(newNode.getParent().getChildren().get(0).getLabel()))
								if(oldCall.getMethodName().equals(newCall.getMethodName()))
								{
//									System.out.println(oldNode.getParent().getChildren().get(0).getLabel());
//									System.out.println(newNode.getParent().getChildren().get(0).getLabel());
									return ChangeType.CHANGE_PAREMETER;
								}
				}
			}
		}	
	
		return ChangeType.NOT_FOUND;
    }
    
    public boolean CheckReturn(ITree parent,TreeContext dstTC)
    {
    	 //直到出现第一个statement，并且为判断 循环 
    	if("IfStatement".equals(dstTC.getTypeLabel(parent))
    	||"ForStatement".equals(dstTC.getTypeLabel(parent)))
    		return true;
    	else if(dstTC.getTypeLabel(parent).contains("Expression"))	
            return CheckReturn(parent.getParent(),dstTC);
    	else			
    	    return false;     
    }
    
    public boolean CheckLabel(ITree parent, ITree variableNode, TreeContext dstTC)
    {
    	List<ITree> childrenNodes = parent.getChildren();
    	Stack<ITree> nodeStack = new Stack<ITree>();  		
    	for(int i=0;i<childrenNodes.size();i++)
    	{
    		if(dstTC.getTypeLabel(childrenNodes.get(i)).contains("Expression"))
    			nodeStack.push(childrenNodes.get(i));   			
    	}
    	while(!nodeStack.isEmpty())
    	{
    		ITree checkNode = nodeStack.pop();
    		List<ITree> checkChildrenNodes = checkNode.getChildren();
    		for(int i=0;i<checkChildrenNodes.size(); i++)
    		{
//        		System.out.println(checkChildrenNodes.get(i).getLabel()+" "+dstTC.getTypeLabel(checkChildrenNodes.get(i)));
    			if("SimpleName".equals(dstTC.getTypeLabel(checkChildrenNodes.get(i))))
        		{  			
        			if(variableNode.getLabel().equals(checkChildrenNodes.get(i).getLabel()))
        			   return true;
        		}
    			if(dstTC.getTypeLabel(checkChildrenNodes.get(i)).contains("Expression"))
    				nodeStack.push(checkChildrenNodes.get(i));
    		}  		
    	}
		return false;
    }
    
    
    public boolean CheckParameterSimpleName(ITree oldNode, ITree newNode)
    {  	
    	List<ITree> oldChildren = null;
    	List<ITree> newChildren = null;
    	oldChildren = oldNode.getParent().getChildren();
    	newChildren = newNode.getParent().getChildren();
    	if(oldChildren.size()!=newChildren.size())
    		return false;
    	if(oldChildren.size()==newChildren.size() && oldChildren.size() == 2)
    		return true;
    	if(oldChildren.size()==newChildren.size())
    	{
            for(int i=2;i<oldChildren.size();i++)
    		    if(!oldChildren.get(i).getLabel().equals(newChildren.get(i).getLabel()))
    		        return false;
            return true;
    	}   		   		
    	return true;
    }
}

package cn.edu.fudan.se.apiChangeExtractor;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.IMethodBinding;
import org.eclipse.jdt.core.dom.ITypeBinding;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jgit.revwalk.RevCommit;

import cn.edu.fudan.se.apiChangeExtractor.PatternMatcher.ChangeType;
import cn.edu.fudan.se.apiChangeExtractor.bean.ChangeFile;
import cn.edu.fudan.se.apiChangeExtractor.bean.JdtMethodCall;
import cn.edu.fudan.se.apiChangeExtractor.bean.Transition;
import cn.edu.fudan.se.apiChangeExtractor.evaluation.ETimer;
import cn.edu.fudan.se.apiChangeExtractor.gumtreeParser.GumTreeDiffParser;
import cn.edu.fudan.se.apiChangeExtractor.mybatis.bean.Apichange;
import cn.edu.fudan.se.apiChangeExtractor.mybatis.bean.ChangeExample;
import cn.edu.fudan.se.apiChangeExtractor.mybatis.bean.InnerChangeExample;
import cn.edu.fudan.se.apiChangeExtractor.mybatis.dao.ApichangeDao;
import cn.edu.fudan.se.apiChangeExtractor.mybatis.dao.ApichangeNotBugDao;

import com.github.gumtreediff.actions.model.Action;
import com.github.gumtreediff.actions.model.Delete;
import com.github.gumtreediff.actions.model.Insert;
import com.github.gumtreediff.actions.model.Move;
import com.github.gumtreediff.actions.model.Update;
import com.github.gumtreediff.tree.ITree;
import com.github.gumtreediff.tree.Tree;
import com.github.gumtreediff.tree.TreeContext;

public class ActionParser {
	private GumTreeDiffParser diff;
	private ApichangeDao dao;
	private ApichangeNotBugDao notBugDao;
	private String webRoot;
	private ChangeFile changeFile;
	private int repositoryId;
	private RevCommit thisCommit;
	private ETimer timer;
	
	public ActionParser(RevCommit thisCommit, GumTreeDiffParser diff, String webRoot, ChangeFile changeFile, int repositoryId, ETimer timer){
		this.thisCommit = thisCommit;
		this.diff = diff;
		dao = new ApichangeDao();
		notBugDao = new ApichangeNotBugDao();
		this.webRoot = webRoot;
		this.changeFile = changeFile;
		this.repositoryId = repositoryId;
		this.timer =timer;
	}
	public Transition parseOneAction(Action a, Transition tran){
		if(a.getNode()==null || diff.dstTC==null)
		    return tran;
		
		PatternMatcher pm = new PatternMatcher();
	    ChangeType changeType = pm.matchOneAction(a, diff.dstTC, diff, tran);
 
	    Apichange apichange = new Apichange();

		//insert record or not 数据库存储操作
		if(!ChangeType.NOT_FOUND.toString().equals(changeType.toString()))
		{
//		    System.out.println();
//		    System.out.print(changeType.toString());
			apichange.setAction(a);
			apichange.setCommitLog(thisCommit.getFullMessage());
			//apichange的赋值
			apichange.setRepositoryId(repositoryId);
			apichange.setWebsite(webRoot+changeFile.getCommitId());
			Date date =new Date(thisCommit.getCommitTime());
			Timestamp timeStamp = new Timestamp(date.getTime());
			apichange.setCommitTime(timeStamp);
			apichange.setCommitId(changeFile.getCommitId());
			apichange.setParentCommitId(changeFile.getParentCommitId());
			apichange.setNewFileName(changeFile.getNewPath());
			apichange.setOldFileName(changeFile.getOldPath());
			ITree newNode = null; 
			ITree oldNode = null;	
			apichange.setChangeType(changeType.toString());  //新表改为int？
			if(a instanceof Insert)
			{
				newNode = a.getNode();
//				oldNode = diff.getMapping().getSrc(newNode);	
				
			}
			if(a instanceof Delete)
			{
				oldNode = a.getNode();				
			}
			if(a instanceof Update)
			{
				oldNode = a.getNode();
				newNode = diff.getMapping().getDst(oldNode);							
			}
			if(a instanceof Move)
			{
				newNode = a.getNode();
				newNode = newNode.getChild(0);
				System.out.println("-------------get move---------------");
				System.out.println("-------------"+changeType+"---------------");
			}
			if(oldNode!=null)
			{
//				System.out.print("oldNode!=null");
				apichange.setOldLineNumber(oldNode.getStartLineNumber());
				apichange.setOldContent(((Tree)oldNode).getAstNode().toString());
				String tempOldParameterName = new String();
				List<ITree> oldChildren= oldNode.getParent().getChildren();
				if(oldChildren.size()>=2)	
				{
					for(int j=2;j<oldChildren.size();j++)
					{
					    tempOldParameterName = tempOldParameterName+oldChildren.get(j).getLabel();
					    if(j!=oldChildren.size()-1)
					    	tempOldParameterName = tempOldParameterName +",";
					}
				}
				apichange.setOldParameterName(tempOldParameterName);
				
				JdtMethodCall oldCall = null;
				if(((Tree)oldNode.getParent()).getAstNode() instanceof MethodInvocation){	
					MethodInvocation tempMI = (MethodInvocation)((Tree)oldNode.getParent()).getAstNode();
					oldCall = diff.getJdkMethodCall(tempMI);
					apichange.setOldMI(tempMI.toString());
				}
				if(oldCall!=null)
				{
//					System.out.print("oldCall!=null");
					apichange.setOldCompleteClassName(oldCall.getInvoker());
					apichange.setOldReceiverName(((Tree)oldNode.getParent()).getChild(0).getLabel());
					apichange.setOldMethodName(oldCall.getMethodName());
					apichange.setOldParameterNum(oldCall.getParameters().size());
					apichange.setOldParameterType(oldCall.getParameterString());
					ITree parent = oldNode.getParent();
					int position  = parent.getChildPosition(oldNode);
//					System.out.println("position int "+position);
					apichange.setParameterPosition(String.valueOf(position-2));
//					System.out.println("position string "+String.valueOf(position-2));
					apichange.setOldCompleteName(apichange.getOldCompleteClassName()+"."+apichange.getOldMethodName()+"("+apichange.getOldParameterType()+")");
//					System.out.println(apichange.getOldCompleteName());
				}
				else
					return tran;
			}
			if(newNode!=null)
			{
//				System.out.print("newNode!=null");
				apichange.setNewLineNumber(newNode.getStartLineNumber());//map去找
				apichange.setNewContent(((Tree)newNode).getAstNode().toString());
				String tempNewParameterName = new String();
				List<ITree> newChildren= newNode.getParent().getChildren();
				if(newChildren.size()>=2)	
				{
					for(int j=2;j<newChildren.size();j++)
					{
					    tempNewParameterName = tempNewParameterName+newChildren.get(j).getLabel();
					    if(j!=newChildren.size()-1)
					    	tempNewParameterName = tempNewParameterName +",";
					}
				}
				apichange.setNewParameterName(tempNewParameterName);
				JdtMethodCall newCall = null;
				if(((Tree)newNode.getParent()).getAstNode() instanceof MethodInvocation){
					MethodInvocation tempMI = (MethodInvocation)((Tree)newNode.getParent()).getAstNode();
					newCall = diff.getJdkMethodCall(tempMI);
					apichange.setNewMI(tempMI.toString());
				}
				if(newCall!=null)
				{
					
//					System.out.print("newCall!=null");
					apichange.setNewCompleteClassName(newCall.getInvoker());
					apichange.setNewReceiverName(((Tree)newNode.getParent()).getChild(0).getLabel());
					apichange.setNewMethodName(newCall.getMethodName());
					apichange.setNewParameterNum(newCall.getParameters().size());
					apichange.setNewParameterType(newCall.getParameterString());	
					if(newCall.isJdk())
					{
//						System.out.println("start add");
						if(apichange.getParameterPosition()==null)
						{							
							ITree parent = newNode.getParent();
							int position  = parent.getChildPosition(newNode);
//							System.out.println("position int "+position);
							apichange.setParameterPosition(String.valueOf(position-2));
//							System.out.println("position string "+String.valueOf(position-2));
						}
						apichange.setNewCompleteName(apichange.getNewCompleteClassName()+"."+apichange.getNewMethodName()+"("+apichange.getNewParameterType()+")");
//						System.out.println(apichange.getNewCompleteName());
						List<Apichange> apichangeList = new ArrayList<>();
						apichangeList = tran.getApichangeList();
						apichangeList.add(apichange);
						tran.setApichangeList(apichangeList);
//						System.out.println("add sucess");
					}
				}	
			}									
		}
		return tran;
	}

	public Transition parseOneActionNotBug(Action a, Transition tran){
		if(a.getNode()==null || diff.dstTC==null)
		    return tran;
		
		PatternMatcher pm = new PatternMatcher();
	    ChangeType changeType = pm.matchOneAction(a, diff.dstTC, diff, tran);
		Apichange apichange = new Apichange();
		//insert record or not 数据库存储操作
		if(!ChangeType.NOT_FOUND.toString().equals(changeType.toString()))
		{
			apichange.setCommitLog(thisCommit.getFullMessage());
			//apichange的赋值
			apichange.setRepositoryId(repositoryId);
			apichange.setWebsite(webRoot+changeFile.getCommitId());
			apichange.setCommitId(changeFile.getCommitId());
			apichange.setParentCommitId(changeFile.getParentCommitId());
			apichange.setNewFileName(changeFile.getNewPath());
			apichange.setOldFileName(changeFile.getOldPath());
			ITree newNode = null; 
			ITree oldNode = null;	
			apichange.setChangeType(changeType.toString());  //新表改为int？
			if(a instanceof Insert)
			{
				newNode = a.getNode();
//				oldNode = diff.getMapping().getSrc(newNode);	
				
			}
			if(a instanceof Update)
			{
				oldNode = a.getNode();
				newNode = diff.getMapping().getDst(oldNode);							
			}
			if(oldNode!=null)
			{
				apichange.setOldLineNumber(oldNode.getStartLineNumber());
				apichange.setOldContent(((Tree)oldNode).getAstNode().toString());
				String tempOldParameterName = new String();
				List<ITree> oldChildren= oldNode.getParent().getChildren();
				if(oldChildren.size()>=2)	
				{
					for(int j=2;j<oldChildren.size();j++)
					{
					    tempOldParameterName = tempOldParameterName+oldChildren.get(j).getLabel();
					    if(j!=oldChildren.size()-1)
					    	tempOldParameterName = tempOldParameterName +",";
					}
				}
				apichange.setOldParameterName(tempOldParameterName);
				
				JdtMethodCall oldCall = null;
				if(((Tree)oldNode.getParent()).getAstNode() instanceof MethodInvocation){	
					MethodInvocation tempMI = (MethodInvocation)((Tree)oldNode.getParent()).getAstNode();
					oldCall = diff.getJdkMethodCall(tempMI);
					apichange.setOldMI(tempMI.toString());
				}
				if(oldCall!=null)
				{
					apichange.setOldCompleteClassName(oldCall.getInvoker());
					apichange.setOldMethodName(oldCall.getMethodName());
					apichange.setOldParameterNum(oldCall.getParameters().size());
					apichange.setOldParameterType(oldCall.getParameterString());
				}
				else
					return tran;
			}
			if(newNode!=null)
			{
				apichange.setNewLineNumber(newNode.getStartLineNumber());//map去找
				apichange.setNewContent(((Tree)newNode).getAstNode().toString());
				String tempNewParameterName = new String();
				List<ITree> newChildren= newNode.getParent().getChildren();
				if(newChildren.size()>=2)	
				{
					for(int j=2;j<newChildren.size();j++)
					{
					    tempNewParameterName = tempNewParameterName+newChildren.get(j).getLabel();
					    if(j!=newChildren.size()-1)
					    	tempNewParameterName = tempNewParameterName +",";
					}
				}
				apichange.setNewParameterName(tempNewParameterName);
				JdtMethodCall newCall = null;
				if(((Tree)newNode.getParent()).getAstNode() instanceof MethodInvocation){
					MethodInvocation tempMI = (MethodInvocation)((Tree)newNode.getParent()).getAstNode();
					newCall = diff.getJdkMethodCall(tempMI);
					apichange.setNewMI(tempMI.toString());
				}
				if(newCall!=null)
				{
					
					apichange.setNewCompleteClassName(newCall.getInvoker());							
					apichange.setNewMethodName(newCall.getMethodName());
					apichange.setNewParameterNum(newCall.getParameters().size());
					apichange.setNewParameterType(newCall.getParameterString());	
					if(newCall.isJdk())
					{

						notBugDao.insertOneApichange(apichange);
					}
				}	
			}									
		}
		return tran;
	}
	
	public Transition fixChangeParameter(Action a, Transition tran){
		if(a.getNode()==null || diff.dstTC==null)
		    return tran;
		
		PatternMatcher pm = new PatternMatcher();
	    ChangeType changeType = pm.matchOneAction(a, diff.dstTC, diff, tran);
		Apichange apichange = new Apichange();
		ChangeExample example = new ChangeExample();
		InnerChangeExample innerExample = new InnerChangeExample();
		//insert record or not 数据库存储操作
//		if("src/test/java/io/reactivex/XFlatMapTest.java".equals(changeFile.getOldPath()))
//			System.out.println("change type: "+changeType.toString());
		if(ChangeType.CHANGE_PAREMETER.toString().equals(changeType.toString()))
		{
			apichange.setCommitLog(thisCommit.getFullMessage());
			//apichange的赋值
			apichange.setRepositoryId(repositoryId);
			apichange.setWebsite(webRoot+changeFile.getCommitId());
			apichange.setCommitId(changeFile.getCommitId());
			apichange.setParentCommitId(changeFile.getParentCommitId());
			apichange.setNewFileName(changeFile.getNewPath());
			apichange.setOldFileName(changeFile.getOldPath());
			ITree newNode = null; 
			ITree oldNode = null;	
			apichange.setChangeType(changeType.toString());  //新表改为int？
			if(a instanceof Insert)
			{
				newNode = a.getNode();
//				oldNode = diff.getMapping().getSrc(newNode);	
				
			}
			if(a instanceof Update)
			{
				oldNode = a.getNode();
				newNode = diff.getMapping().getDst(oldNode);							
			}
			if(oldNode!=null)
			{
				apichange.setOldLineNumber(oldNode.getStartLineNumber());
				apichange.setOldContent(((Tree)oldNode).getAstNode().toString());
				String tempOldParameterName = new String();
				List<ITree> oldChildren= oldNode.getParent().getChildren();
				if(oldChildren.size()>=2)	
				{
					for(int j=2;j<oldChildren.size();j++)
					{
					    tempOldParameterName = tempOldParameterName+oldChildren.get(j).getLabel();
					    if(j!=oldChildren.size()-1)
					    	tempOldParameterName = tempOldParameterName +",";
					}
				}
				apichange.setOldParameterName(tempOldParameterName);
				
				JdtMethodCall oldCall = null;
				if(((Tree)oldNode.getParent()).getAstNode() instanceof MethodInvocation){	
					MethodInvocation tempMI = (MethodInvocation)((Tree)oldNode.getParent()).getAstNode();
					oldCall = diff.getJdkMethodCall(tempMI);
					apichange.setOldMI(tempMI.toString());
				}
				if(oldCall!=null)
				{
					apichange.setOldCompleteClassName(oldCall.getInvoker());
					apichange.setOldMethodName(oldCall.getMethodName());
					apichange.setOldParameterNum(oldCall.getParameters().size());
					apichange.setOldParameterType(oldCall.getParameterString());
					ITree parent = oldNode.getParent();
					int position  = parent.getChildPosition(oldNode);
//					System.out.println("position int"+position);
					apichange.setParameterPosition(String.valueOf(position-2));
//					System.out.println("position string"+String.valueOf(position-2));
//					System.out.println(position);
				}
				else
					return tran;
			}
			if(newNode!=null)
			{
				apichange.setNewLineNumber(newNode.getStartLineNumber());//map去找
				apichange.setNewContent(((Tree)newNode).getAstNode().toString());
				String tempNewParameterName = new String();
				List<ITree> newChildren= newNode.getParent().getChildren();
				if(newChildren.size()>=2)	
				{
					for(int j=2;j<newChildren.size();j++)
					{
					    tempNewParameterName = tempNewParameterName+newChildren.get(j).getLabel();
					    if(j!=newChildren.size()-1)
					    	tempNewParameterName = tempNewParameterName +",";
					}
				}
				apichange.setNewParameterName(tempNewParameterName);
				JdtMethodCall newCall = null;
				if(((Tree)newNode.getParent()).getAstNode() instanceof MethodInvocation){
					MethodInvocation tempMI = (MethodInvocation)((Tree)newNode.getParent()).getAstNode();
					newCall = diff.getJdkMethodCall(tempMI);
					apichange.setNewMI(tempMI.toString());
				}
				if(newCall!=null)
				{
					
					apichange.setNewCompleteClassName(newCall.getInvoker());							
					apichange.setNewMethodName(newCall.getMethodName());
					apichange.setNewParameterNum(newCall.getParameters().size());
					apichange.setNewParameterType(newCall.getParameterString());	
					if(newCall.isJdk())
					{
//						if(apichange.getRepositoryId()==1)
//							System.out.println(apichange.toString());
						dao.updateParameterPosition(apichange);
					}
				}	
			}									
		}
		return tran;
	}
	
	
	public void printOneAction(Action a,GumTreeDiffParser diff){
		if(a instanceof Delete){
			System.out.print("Delete>");
			Delete delete = (Delete)a;
			ITree deleteNode = delete.getNode();
			System.out.println(prettyString(diff.dstTC,deleteNode)+" from "+prettyString(diff.dstTC,deleteNode.getParent()));//old
			System.out.println(delete.toString());
			PatternMatcher pm = new PatternMatcher();
			Transition tran = new Transition();						
			ChangeType changeType = pm.matchOneAction(a, diff.dstTC, diff, tran);
			System.out.println(changeType);
		}
		if(a instanceof Insert){
			System.out.print("Insert>");
			Insert insert = (Insert)a;
			ITree insertNode = insert.getNode();
			System.out.println(prettyString(diff.dstTC,insertNode)+" to "+prettyString(diff.dstTC,insertNode.getParent())+" at "+ insert.getPosition());
			System.out.println(insert.toString());
			PatternMatcher pm = new PatternMatcher();
			Transition tran = new Transition();						
			ChangeType changeType = pm.matchOneAction(a, diff.dstTC, diff, tran);
			System.out.println(changeType);
			System.out.println("----------------Insert.getParent(Old Tree)----------------------------");
			System.out.println(prettyString(diff.dstTC, insert.getParent()));//old
		}
		if(a instanceof Move){
			System.out.print("Move>");
			Move move = (Move)a;
			ITree moveNode = move.getNode();
			System.out.println(prettyString(diff.dstTC,moveNode)+" to "+prettyString(diff.dstTC,move.getParent())+" at "+ move.getPosition());//old
			System.out.println(move.toString());
			System.out.println(move.getParent()==move.getNode().getParent());
			PatternMatcher pm = new PatternMatcher();
			Transition tran = new Transition();						
			ChangeType changeType = pm.matchOneAction(a, diff.dstTC, diff, tran);
			System.out.println(changeType);
			System.out.println("----------------Move.getParent(New Tree)----------------------------");
			System.out.println(prettyString(diff.dstTC, move.getParent()));//new
		}
		if(a instanceof Update){
			System.out.print("Update>");
			Update update = (Update)a;
			ITree updateNode = update.getNode();
			System.out.println("from "+updateNode.getLabel()+" to "+update.getValue());//old
			PatternMatcher pm = new PatternMatcher();
			Transition tran = new Transition();						
			ChangeType changeType = pm.matchOneAction(a, diff.dstTC, diff, tran);
			System.out.println(changeType);
//			System.out.println("testLineNumber**************"+((Tree)updateNode).getStartLineNumber());
		}
		System.out.println("----------------Action.getNode----------------------------");
		System.out.println(prettyString(diff.dstTC, a.getNode()));//move-old,update-old,insert-new,delete-old
//		System.out.println(toTreeString(dstTC, a.getNode()));
		System.out.println("-----------------Action.getNode.getParent---------------------------");
		System.out.println(prettyString(diff.dstTC, a.getNode().getParent()));//move-old,update-old,insert-new,delete-old
//		System.out.println(toTreeString(dstTC, a.getNode().getParent()));
		System.out.println("============================================");		
	}
	
	public String prettyString(TreeContext con, ITree node){
		if("MethodInvocation".equals(con.getTypeLabel(node))){
			JdtMethodCall temp = getJdkMethodCall((MethodInvocation)((Tree)node).getAstNode());
			if(temp != null)
				return node.getId()+". "+con.getTypeLabel(node)+":"+node.getLabel()+"("+getStartLineNum(con,node)+"-"+getEndLineNum(con,node)+")"+"|\n"+temp.toString()+"|"+temp.isJdk();
		}
		return node.getId()+". "+con.getTypeLabel(node)+":"+node.getLabel()+"("+getStartLineNum(con,node)+"-"+getEndLineNum(con,node)+")";
	}
	
	public JdtMethodCall getJdkMethodCall(MethodInvocation md){
    	IMethodBinding mb = md.resolveMethodBinding();
        //如果binding有效，且通过对象或类名调用
        if(mb!=null&&md.getExpression()!=null){
        	JdtMethodCall jdtBinding = new JdtMethodCall(md.getExpression().resolveTypeBinding().getQualifiedName(),
        			mb.getName(), mb.getReturnType().getQualifiedName(), mb.getDeclaringClass().getQualifiedName());
            ITypeBinding[] list = mb.getParameterTypes();
            for(int i = 0; i < list.length; i++){
            	jdtBinding.addParameter(list[i].getQualifiedName());
            }
            jdtBinding.setJdk(isJdk(md.getExpression().resolveTypeBinding().getQualifiedName()));
            return jdtBinding;
        }else if(mb!=null)
        {
        	System.out.println("---------------------------------------------------------------------");
        	System.out.println(mb);
        	System.out.println("---------------------------------------------------------------------");
        	return null;
        }              
        else{
        	return null;
        }
    }
	private boolean isJdk(String s){
    	try {
    		String temp = s;
    		if(temp.contains("<")){
    			temp = temp.split("<")[0];
    		}
			Class.forName(temp);
			return true;
		} catch (ClassNotFoundException e) {
	    	return false;
		}
    }
	public int getStartLineNum(TreeContext con, ITree node){
    	ASTNode n = ((Tree) node).getAstNode();
		return con.getCu().getLineNumber(n.getStartPosition());
	}
    public int getEndLineNum(TreeContext con, ITree node){
    	ASTNode n = ((Tree) node).getAstNode();
		return con.getCu().getLineNumber(n.getStartPosition()+n.getLength()-1);
	}
	
    
    public Transition parseOneActionForMotheodNum(Action a, Transition tran){
		if(a.getNode()==null || diff.dstTC==null)
		    return tran;
		
		PatternMatcher pm = new PatternMatcher();
	    ChangeType changeType = pm.matchOneAction(a, diff.dstTC, diff, tran);
		
	    Map<Integer,Integer> JDKMethodInovationNum = tran.getJDKmethodInovationNum();    	   
	    Map<Integer,Integer> UselessMethodInovationNum = tran.getUselessMethodInovationNum();  
	    
		//insert record or not 数据库存储操作
	    ITree node = a.getNode();
	    if(ChangeType.NOT_FOUND.toString().equals(changeType.toString()))
		{
			ITree newNode = null; 
			ITree oldNode = null;				
			
			if(a instanceof Insert)
			{		
				if("MethodInvocation".equals(diff.dstTC.getTypeLabel(node)))	
				{	
					newNode = a.getNode();	
					if(newNode!=null)
					{
						JdtMethodCall newCall = null;
						if(((Tree)newNode.getParent()).getAstNode() instanceof MethodInvocation){
							MethodInvocation tempMI = (MethodInvocation)((Tree)newNode.getParent()).getAstNode();
							newCall = diff.getJdkMethodCall(tempMI);
						}
						if(newCall!=null)
						{	
							if(!JDKMethodInovationNum.containsKey(newNode.getParent()))
							{
								JDKMethodInovationNum.put(newNode.getParent().getId(), 2);	
//								System.out.println("#################################");								
//								System.out.println("JDKUM  insert");
//								printOneAction(a, diff);
							}
						}
						else
						{
							if(!UselessMethodInovationNum.containsKey(newNode.getParent()))
							{
								UselessMethodInovationNum.put(newNode.getParent().getId(), 0);	 
//								System.out.println("#################################");								
//								System.out.println("UM  insert");
//								printOneAction(a, diff);
							}						
						}	
					}
				
				}
			}
			if(a instanceof Delete)
			{	
				if("MethodInvocation".equals(diff.dstTC.getTypeLabel(node)))	
				{
					oldNode = a.getNode();
					if(oldNode!=null)
					{		
						JdtMethodCall oldCall = null;
						if(((Tree)oldNode.getParent()).getAstNode() instanceof MethodInvocation){	
							MethodInvocation tempMI = (MethodInvocation)((Tree)oldNode.getParent()).getAstNode();
							oldCall = diff.getJdkMethodCall(tempMI);
						}
						if(oldCall!=null)
						{
								if(!JDKMethodInovationNum.containsKey(oldNode.getParent()))
								{
									JDKMethodInovationNum.put(oldNode.getParent().getId(), 2);	
//									System.out.println("#################################");								
//									System.out.println("JDKUM  delete");
//									printOneAction(a, diff);
								}
						}
						else
						{
							if(!UselessMethodInovationNum.containsKey(oldNode.getParent()))
							{
									UselessMethodInovationNum.put(oldNode.getParent().getId(), 0);	 
//									System.out.println("#################################");								
//									System.out.println("UM  delete");
//									printOneAction(a, diff);
							}
						}						
					}
				}
			}
			if(a instanceof Update)
			{				
				if("MethodInvocation".equals(diff.dstTC.getTypeLabel(node)))	
				{
					oldNode = a.getNode();
					if(oldNode!=null)
					{		
						JdtMethodCall oldCall = null;
						if(((Tree)oldNode.getParent()).getAstNode() instanceof MethodInvocation){	
							MethodInvocation tempMI = (MethodInvocation)((Tree)oldNode.getParent()).getAstNode();
							oldCall = diff.getJdkMethodCall(tempMI);
						}
						if(oldCall!=null)
						{
							if(!JDKMethodInovationNum.containsKey(oldNode.getParent()))
							{
								JDKMethodInovationNum.put(oldNode.getParent().getId(), 0);	
//								System.out.println("#################################");								
//								System.out.println("JDKUM  update");
//								printOneAction(a, diff);
							}	
						}
						else
						{
							if(!UselessMethodInovationNum.containsKey(oldNode.getParent()))
							{
								UselessMethodInovationNum.put(oldNode.getParent().getId(), 0);	
//								System.out.println("#################################");								
//								System.out.println("UM  update");
//								printOneAction(a, diff);
							}						
						}
					}
				}
			}
			if(a instanceof Move)
			{			
				if("MethodInvocation".equals(diff.dstTC.getTypeLabel(node)))	
				{	
					newNode = a.getNode();
					if(newNode!=null)
					{
						JdtMethodCall newCall = null;
						if(((Tree)newNode).getAstNode() instanceof MethodInvocation){
							MethodInvocation tempMI = (MethodInvocation)((Tree)newNode).getAstNode();
							newCall = diff.getJdkMethodCall(tempMI);
						}
						if(newCall!=null)
						{	

							if(!JDKMethodInovationNum.containsKey(newNode))
							{
								JDKMethodInovationNum.put(newNode.getId(), 0);	 
//								System.out.println("#################################");								
//								System.out.println("JDKUM  update");
//								printOneAction(a, diff);
							}
						}
						else
						{
							if(!UselessMethodInovationNum.containsKey(newNode.getParent()))
								UselessMethodInovationNum.put(newNode.getParent().getId(), 0);	 
						}							
					}			
				}
			}	
		}
    
	    if(!ChangeType.NOT_FOUND.toString().equals(changeType.toString()))
		{

			ITree newNode = null; 
			ITree oldNode = null;				

			if(a instanceof Insert)
			{						
				newNode = a.getNode();
				if(newNode!=null)
				{
					JdtMethodCall newCall = null;
					if(((Tree)newNode.getParent()).getAstNode() instanceof MethodInvocation){
						MethodInvocation tempMI = (MethodInvocation)((Tree)newNode.getParent()).getAstNode();
						newCall = diff.getJdkMethodCall(tempMI);
					}
					if(newCall!=null)	
						JDKMethodInovationNum.put(newNode.getParent().getId(), 1);	
					else
						UselessMethodInovationNum.put(newNode.getParent().getId(), 1);	 	
				}							
			}
				
				
			if(a instanceof Delete)
			{	
				oldNode = a.getNode();
				if(oldNode!=null)
				{		
					JdtMethodCall oldCall = null;
					if(((Tree)oldNode.getParent()).getAstNode() instanceof MethodInvocation){	
						MethodInvocation tempMI = (MethodInvocation)((Tree)oldNode.getParent()).getAstNode();
						oldCall = diff.getJdkMethodCall(tempMI);
					}
					if(oldCall!=null)
						JDKMethodInovationNum.put(oldNode.getParent().getId(), 1);	 
					else
						UselessMethodInovationNum.put(oldNode.getParent().getId(), 1);	 
					}
			}
			if(a instanceof Update)
			{
				if("MethodInvocation".equals(diff.dstTC.getTypeLabel(node)))	
				{
					oldNode = a.getNode();
					if(oldNode!=null)
					{		
						JdtMethodCall oldCall = null;
						if(((Tree)oldNode.getParent()).getAstNode() instanceof MethodInvocation){	
							MethodInvocation tempMI = (MethodInvocation)((Tree)oldNode.getParent()).getAstNode();
							oldCall = diff.getJdkMethodCall(tempMI);
						}
						if(oldCall!=null)						
							JDKMethodInovationNum.put(oldNode.getParent().getId(), 1);	 
						else
							UselessMethodInovationNum.put(oldNode.getParent().getId(), 1);	 
						
					}	
				}
			}
			if(a instanceof Move)
			{
				if("MethodInvocation".equals(diff.dstTC.getTypeLabel(node)))	
				{	
					newNode = a.getNode();
					if(newNode!=null)
					{
						JdtMethodCall newCall = null;
						if(((Tree)newNode).getAstNode() instanceof MethodInvocation){
							MethodInvocation tempMI = (MethodInvocation)((Tree)newNode).getAstNode();
							newCall = diff.getJdkMethodCall(tempMI);
						}
						if(newCall!=null)
							JDKMethodInovationNum.put(newNode.getId(), 1);	
						else
							UselessMethodInovationNum.put(newNode.getId(), 1);	 
	
					}			
				}
			}							
		}
		return tran;
	}
    
}

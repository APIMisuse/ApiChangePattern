package sav.common.core.utils;

public interface Predicate<T> {
    public boolean apply(T val);
}


/*
 * This file is part of GumTree.
 *
 * GumTree is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * GumTree is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with GumTree.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Copyright 2011-2015 Jean-Rémy Falleri <jr.falleri@gmail.com>
 * Copyright 2011-2015 Floréal Morandat <florealm@gmail.com> *
 */


package com.github.gumtreediff.jdt;

import org.eclipse.jdt.core.dom.*;

public class JdtVisitor  extends AbstractJdtVisitor {
    public JdtVisitor() {
        super();
    }

    @Override
    public void preVisit(ASTNode n) {
        pushNode(n, getLabel(n));
    }

    protected String getLabel(ASTNode n) {
        if (n instanceof Name) return ((Name) n).getFullyQualifiedName();
        if (n instanceof Type) return n.toString();
        if (n instanceof Modifier) return n.toString();
        if (n instanceof StringLiteral) return ((StringLiteral) n).getEscapedValue();
        if (n instanceof NumberLiteral) return ((NumberLiteral) n).getToken();
        if (n instanceof CharacterLiteral) return ((CharacterLiteral) n).getEscapedValue();
        if (n instanceof BooleanLiteral) return ((BooleanLiteral) n).toString();
        if (n instanceof InfixExpression) return ((InfixExpression) n).getOperator().toString();
        if (n instanceof PrefixExpression) return ((PrefixExpression) n).getOperator().toString();
        if (n instanceof PostfixExpression) return ((PostfixExpression) n).getOperator().toString();
        if (n instanceof Assignment) return ((Assignment) n).getOperator().toString();
        if (n instanceof TextElement) return n.toString();
        if (n instanceof TagElement) return ((TagElement) n).getTagName();

        return "";
    }
//    @Override
//    public boolean visit(MethodInvocation md) {
//        System.out.println("******************************************************************************************");
//        IMethodBinding mb = md.resolveMethodBinding();
//        //如果binding有效，且通过对象或类名调用
//        if(mb!=null&&md.getExpression()!=null){
//        	System.out.println(md.getExpression().resolveTypeBinding().getQualifiedName());
//            System.out.println(mb.getName());
//            System.out.println(mb.getReturnType().getQualifiedName()); 
//            System.out.println(mb.getDeclaringClass().getQualifiedName());
//            ITypeBinding[] list = mb.getParameterTypes();
//            for(int i = 0; i < list.length; i++){
//            	System.out.println("->"+list[i].getQualifiedName());
//            }
//        }else{
//        	if(mb==null)
//        		System.out.println(md.getName()+" is null.");
//        	if(md.getExpression()==null)
//        		System.out.println(md.getName()+" is local method.");
//        }
//        System.out.println("******************************************************************************************");
//        return true;
//    }
//  @Override
//  public boolean visit(FieldDeclaration md) {
//      System.out.println("******************************************************************************************");
//      System.out.println(md.toString());
//      System.out.println(md.getType().resolveBinding().getQualifiedName());
//      System.out.println(((VariableDeclarationFragment)md.fragments().get(0)).getName().toString());
//      System.out.println("******************************************************************************************");
//      return true;
//  }
    @Override
    public boolean visit(TagElement e) {
        return true;
    }

    @Override
    public boolean visit(QualifiedName name) {
        return false;
    }

    @Override
    public void postVisit(ASTNode n) {
        popNode();
    }
}

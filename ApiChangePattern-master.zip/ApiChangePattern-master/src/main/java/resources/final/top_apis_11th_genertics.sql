SELECT * FROM temp.top_apis_11th_generics;

alter table temp.top_apis_11th_generics rename temp.top_apis_11th_generics_temp;
create table temp.top_apis_11th_generics like temp.top_apis_11th;

INSERT INTO  temp.top_apis_11th_generics(class_name,method_name,bug_total,bug_r,bug_rate)  
select class_name, method_name,bug_total,bug_r ,rate from
(
select 
ifnull(a.old_class_name, b.old_class_name) class_name,
ifnull(a.old_method_name, b.old_method_name) method_name,
ifnull(a.total,0) bug_total,
ifnull(b.repository_num,0) bug_r,
a.total/b.repository_num as rate
 from 
(SELECT old_class_name,old_method_name, COUNT(*) as total 
FROM temp.apichange_11th_generics 
where old_class_name <> ''
group by old_class_name,old_method_name)
as a 
JOIN 
(SELECT old_class_name,old_method_name, COUNT(*) as repository_num
FROM (SELECT distinct old_class_name,old_method_name, repository_id FROM apichange_11th_generics where old_class_name <> ''
group by old_class_name,old_method_name,repository_id)as c group by c.old_class_name,c.old_method_name)
as b
on a.old_class_name = b.old_class_name and
a.old_method_name = b.old_method_name
) as d;

update temp.top_apis_11th_generics set class_method = CONCAT(class_name,'.',method_name);

update temp.top_apis_11th_generics as a inner join
(SELECT substring_index (api_name,'(', 1) as class_method , count(*) as num from codehub.java_repo_api group by substring_index (api_name,'(', 1)) as b
on a.class_method = b.class_method set a.repo_total = b.num;

create table java_repo_api like codehub.java_repo_api;
insert into temp.java_repo_api select * from codehub.java_repo_api;

alter table temp.java_repo_api add column class_method varchar(512);

update temp.java_repo_api set class_method = substring_index (api_name,'(', 1);

ALTER TABLE `java_repo_api` ADD INDEX classMethod ( `class_method` ) ;

select c.class_method,count(*) as repository_num from
(select distinct class_method, repoid from temp.java_repo_api group by class_method,repoid)as c
group by c.class_method;

ALTER TABLE `java_repo_api` ADD INDEX repositoryid ( `repoid` ) ;

update temp.top_apis_11th_generics as a inner join
(select c.class_method,count(*) as repository_num from
(select distinct class_method, repoid from temp.java_repo_api group by class_method,repoid)as c
group by c.class_method) as b
on a.class_method = b.class_method set a.repo_r = b.repository_num;

update temp.top_apis_11th_generics set repo_rate = repo_total/repo_r;

alter table temp.top_apis_11th_generics modify  column repo_rate double;

update temp.top_apis_11th_generics set bug_rank = 
((0.7*(bug_r-0.999)/176.00)+(0.3*(bug_total/bug_r-0.999)/8.00))/((0.7*(repo_r-0.999)/1334.00)+(0.3*(repo_total/repo_r-0.999)/625.00)) 
where bug_total is not null and bug_r is not null and repo_total is not null and repo_r is not null;

select (0.8*(repo_r-1)/1334.00)+(0.2*(repo_total/repo_r-1)/625.00),class_method,repo_r,repo_total  from temp.top_apis_11th_generics;

SELECT * FROM temp.top_apis_11th_generics where bug_rate/repo_rate>0.2 and bug_total>15;
SELECT * FROM temp.top_apis_11th_generics where bug_total>15;
SELECT * FROM temp.top_apis_11th_generics;
SELECT * FROM temp.top_apis_11th_generics order by repo_total desc limit 200;
SELECT * FROM temp.top_apis_11th_generics order by bug_total desc limit 200;




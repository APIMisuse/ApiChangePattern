SELECT old_complete_class_name, old_method_name, COUNT(*) as repository_num
FROM (SELECT distinct old_complete_class_name, old_method_name, repository_id FROM apichange_10th where old_complete_class_name is not NULL) as a
group by a.old_complete_class_name, a.old_method_name ORDER BY repository_num desc;
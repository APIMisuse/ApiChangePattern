select entity_id, qualified_name,bug_total,bug_r ,rate from
(
select 
ifnull(a.old_entity_id, b.old_entity_id) entity_id,
ifnull(a.old_complete_name, b.old_complete_name) qualified_name,
ifnull(a.total,0) bug_total,
ifnull(b.repository_num,0) bug_r,
a.total/b.repository_num as rate
 from 
(SELECT old_entity_id,old_complete_name, COUNT(*) as total 
FROM temp.apichange_10th
where old_entity_id <> 0
group by old_entity_id)
as a 
JOIN 
(SELECT old_entity_id,old_complete_name, COUNT(*) as repository_num
FROM (SELECT distinct old_entity_id, old_complete_name, repository_id FROM apichange_10th where old_entity_id<>0) as c
group by c.old_entity_id) 
as b 
on a.old_entity_id=b.old_entity_id
ORDER BY total desc) as d
#where d.entity_id in (17630,17743,17868)


#ORDER BY repository_num desc
#ORDER BY rate desc

;
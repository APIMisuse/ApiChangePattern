SELECT * FROM temp.apichange_11th;
create table apichange_11th like temp.apichange_10th;
alter table temp.apichange_11th drop column old_entity_id;
alter table temp.apichange_11th drop column new_entity_id;
create table apichange_11th_backup like temp.apichange_11th;
insert into apichange_11th_backup select * from temp.apichange_11th;

select class_name, method_name,bug_total,bug_r ,rate from
(
select   
ifnull(a.old_complete_class_name, b.old_complete_class_name) class_name,
ifnull(a.old_method_name, b.old_method_name) method_name,
ifnull(a.total,0) bug_total,
ifnull(b.repository_num,0) bug_r,
a.total/b.repository_num as rate
 from 
(SELECT old_complete_class_name,old_method_name, COUNT(*) as total 
FROM temp.apichange_11th 
where old_complete_class_name <> ''
group by old_complete_class_name,old_method_name)
as a 
JOIN 
(SELECT old_complete_class_name,old_method_name, COUNT(*) as repository_num
FROM (SELECT distinct old_complete_class_name,old_method_name, repository_id FROM apichange_11th where old_complete_class_name <> ''
group by old_complete_class_name,old_method_name,repository_id)as c group by c.old_complete_class_name,c.old_method_name)
as b
on a.old_complete_class_name = b.old_complete_class_name and
a.old_method_name = b.old_method_name
) as d;


SELECT * FROM temp.apichange_11th where old_complete_name like '%java.util.ArrayList.add%';

alter table temp.apichange_11th rename temp.apichange_11th_temp_2;

DROP TABLE IF EXISTS temp.apichange_11th;
create table temp.apichange_11th like temp.apichange_11th_temp_2;

select * from temp.apichange_11th where left(temp.apichange_11th.old_content, 1)='"' and right(temp.apichange_11th.old_content, 1)='"';

delete from temp.apichange_11th where left(temp.apichange_11th.old_content, 1)='"' and right(temp.apichange_11th.old_content, 1)='"' and change_type = 'CHANGE_PAREMETER';

SELECT * FROM temp.apichange_11th where change_type ='CHANGE_CLASSOBJECT';

SELECT * FROM temp.apichange_11th where change_type ='CHANGE_CLASSOBJECT_REST';

SELECT * FROM temp.apichange_11th where change_type ='CHANGE_CLASSOBJECT_REST' and old_mi like '%equals%';

select * from temp.apichange_11th where left(temp.apichange_11th.old_content, 1)='"' and right(temp.apichange_11th.old_content, 1)='"';

select * from temp.apichange_11th where old_complete_name = 'java.lang.String.equals(java.lang.Object)' and new_complete_name = 'java.lang.String.equalsIgnoreCase(java.lang.String)';


SELECT * FROM temp.apichange_11th where change_type ='RETURN_VALUE_ASSIGNMENT';
SELECT repository_id,COUNT(*) FROM temp.apichange_11th where change_type ='RETURN_VALUE_ASSIGNMENT' group by repository_id;

SELECT * FROM temp.apichange_11th where change_type ='CHANGE_PAREMETER' and left(temp.apichange_11th.old_content, 1)='"' and right(temp.apichange_11th.old_content, 1)='"';
SELECT repository_id,COUNT(*) FROM temp.apichange_11th where change_type ='CHANGE_PAREMETER' and left(temp.apichange_11th.old_content, 1)='"' and right(temp.apichange_11th.old_content, 1)='"' group by repository_id;

SELECT * FROM temp.apichange_11th where change_type ='CHANGE_METHOD';
SELECT repository_id,COUNT(*) FROM temp.apichange_11th where change_type ='CHANGE_METHOD' group by repository_id;

SELECT * FROM temp.apichange_11th where change_type ='DIFFERENT_CLASS';
SELECT repository_id,COUNT(*) FROM temp.apichange_11th where change_type ='DIFFERENT_CLASS' group by repository_id;

SELECT * FROM temp.apichange_11th where change_type ='CHANGE_CLASSOBJECT' or change_type ='CHANGE_CLASSOBJECT_REST';
SELECT repository_id,COUNT(*) FROM temp.apichange_11th where change_type ='RETURN_VALUE_ASSIGNMENT' or change_type ='CHANGE_CLASSOBJECT_REST' group by repository_id;




SELECT apichange_id, old_complete_class_name, old_method_name, COUNT(*) as total 
FROM temp.apichange_10th
where old_complete_class_name is not null or old_method_name is not null
group by old_complete_class_name, old_method_name ORDER BY total desc; 
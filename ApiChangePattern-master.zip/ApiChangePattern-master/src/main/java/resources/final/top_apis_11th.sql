SELECT * FROM temp.top_apis_11th;

create table temp.apichange_11th_generics like temp.apichange_11th;

INSERT INTO  temp.top_apis_11th(class_name,method_name,bug_total,bug_r,bug_rate)  
select class_name, method_name,bug_total,bug_r ,rate from
(
select 
ifnull(a.old_complete_class_name, b.old_complete_class_name) class_name,
ifnull(a.old_method_name, b.old_method_name) method_name,
ifnull(a.total,0) bug_total,
ifnull(b.repository_num,0) bug_r,
a.total/b.repository_num as rate
 from 
(SELECT old_complete_class_name,old_method_name, COUNT(*) as total 
FROM temp.apichange_11th 
where old_complete_class_name <> ''
group by old_complete_class_name,old_method_name)
as a 
JOIN 
(SELECT old_complete_class_name,old_method_name, COUNT(*) as repository_num
FROM (SELECT distinct old_complete_class_name,old_method_name, repository_id FROM apichange_11th where old_complete_class_name <> ''
group by old_complete_class_name,old_method_name,repository_id)as c group by c.old_complete_class_name,c.old_method_name)
as b
on a.old_complete_class_name = b.old_complete_class_name and
a.old_method_name = b.old_method_name
) as d;

alter table temp.top_apis_11th add column class_method varchar(255);

update temp.top_apis_11th set class_method = CONCAT(substring_index (class_name,'<', 1),'.',method_name);

alter table temp.top_apis_11th rename temp.top_apis_11th_temp;

create table temp.top_apis_11th like temp.top_apis_11th_temp;


SELECT CONCAT(class_name,'.',method_name) as class_method from  temp.top_apis_11th;
SELECT distinct substring_index (api_name,'(', 1) as class_method , count(*) as num from codehub.java_repo_api group by substring_index (api_name,'(', 1) ; 

update temp.top_apis_11th as a inner join
(SELECT distinct substring_index (api_name,'(', 1) as class_method , count(*) as num from codehub.java_repo_api group by substring_index (api_name,'(', 1)) as b
on a.class_method = b.class_method set a.repo_total = b.num;
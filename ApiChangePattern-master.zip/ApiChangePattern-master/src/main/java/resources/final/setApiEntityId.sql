update temp.apichange_10th api, codehub.java_all_api_entity entity SET api.old_entity_id = entity.id 
  where entity.qualified_name = api.old_complete_name ;
update temp.apichange_10th api, codehub.java_all_api_entity entity SET api.new_entity_id = entity.id 
  where entity.qualified_name = api.new_complete_name ;
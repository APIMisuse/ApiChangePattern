SELECT * FROM temp.top_api_pattern_method_11th;

alter table temp.top_api_pattern_method_11th rename temp.top_api_pattern_method_11th_temp;
DROP TABLE IF EXISTS temp.top_api_pattern_method_11th;
create table temp.top_api_pattern_method_11th like temp.top_api_pattern_method_11th_temp;

INSERT INTO  temp.top_api_pattern_method_11th(old_complete_name,new_complete_name,bug_total,bug_r,bug_rate) 
select old_complete_name, new_complete_name,bug_total,bug_r ,rate from
(
select   
ifnull(a.old_complete_name, b.old_complete_name) old_complete_name,
ifnull(a.new_complete_name, b.new_complete_name) new_complete_name,
ifnull(a.total,0) bug_total,
ifnull(b.repository_num,0) bug_r,
a.total/b.repository_num as rate
 from 
(SELECT old_complete_name,new_complete_name, COUNT(*) as total 
FROM temp.apichange_11th_temp_2 
where old_complete_name <> '' and change_type = 'CHANGE_METHOD'
group by old_complete_name,new_complete_name)
as a 
JOIN 
(SELECT old_complete_name,new_complete_name, COUNT(*) as repository_num
FROM (SELECT distinct old_complete_name,new_complete_name, repository_id 
FROM apichange_11th_temp_2
where old_complete_name <> '' and change_type = 'CHANGE_METHOD'
group by old_complete_name,new_complete_name,repository_id)as c group by c.old_complete_name,c.new_complete_name)
as b
on a.old_complete_name = b.old_complete_name and
a.new_complete_name = b.new_complete_name
) as d;


SELECT * FROM temp.top_api_pattern_method_11th where bug_r>1;

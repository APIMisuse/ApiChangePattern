create table high_quality_repositry_1 like temp.highqualityrepositry;

ALTER TABLE temp.high_quality_repositry_1 CHANGE id id INT(11)  NOT NULL AUTO_INCREMENT;

SELECT * FROM temp.high_quality_repositry_1;

insert into temp.high_quality_repositry_1(website,stars,repository_id) 
SELECT url,stars,repository_id FROM codehub.repository_high_quality;
SELECT * FROM temp.top_qualified_api_1;
SELECT * FROM temp.top_qualified_api_1 where qualified_name like '%javax.xml.stream.XMLStreamWriter.writeStartElement%';

delete from  temp.top_qualified_api_1;
truncate table temp.top_qualified_api_1;

insert into temp.top_qualified_api_1(entity_id,qualified_name,bug_total,bug_r,rate)  select entity_id, qualified_name,bug_total,bug_r ,rate
from 
(select entity_id, qualified_name,bug_total,bug_r ,rate from
(
select 
ifnull(a.old_entity_id, b.old_entity_id) entity_id,
ifnull(a.old_complete_name, b.old_complete_name) qualified_name,
ifnull(a.total,0) bug_total,
ifnull(b.repository_num,0) bug_r,
a.total/b.repository_num as rate
 from 
(SELECT old_entity_id,old_complete_name, COUNT(*) as total 
FROM temp.apichange_10th
where old_entity_id <> 0
group by old_entity_id)
as a 
JOIN 
(SELECT old_entity_id,old_complete_name, COUNT(*) as repository_num
FROM (SELECT distinct old_entity_id, old_complete_name, repository_id FROM apichange_10th where old_entity_id<>0) as c
group by c.old_entity_id) 
as b 
on a.old_entity_id=b.old_entity_id
ORDER BY total desc) as d)as e;


UPDATE temp.top_qualified_api_1 a
LEFT JOIN (SELECT api_name,count(*) as number FROM codehub.java_repo_api group by api_name) as b ON a.qualified_name = b.api_name
SET a.used_num = b.number ;

UPDATE temp.top_qualified_api_1 set bug_rank =  bug_total/used_num;

# ApiChangeExactor

nohup java -Xmx2048M -XX:-UseGCOverheadLimit -jar apichange040.jar notbug&

nohup java -Xmx2048M -XX:-UseGCOverheadLimit -jar apichange-test.jar high&